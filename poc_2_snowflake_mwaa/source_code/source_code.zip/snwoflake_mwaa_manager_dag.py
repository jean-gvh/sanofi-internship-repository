from datetime import timedelta
import logging
import logging
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.models import Variable
from airflow.utils.dates import days_ago
import boto3
import requests
import snowflake.connector as snow
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
import base64

# Set up logger for Airflow
logger = logging.getLogger(__name__)

ENV_NAME = "digital-mwaa-global-environment-dev"
REGION_NAME = "eu-west-1"

SNOWSQL_TRANSFORM_USER = Variable.get("oasis_manufacturing-execution-df/MWAA_TRANSFORM_USER")
SNOWSQL_PRV_KEY = Variable.get("oasis_manufacturing-execution-df/MWAA_TRANSFORM_SNOWSQL_PRV_KEY")
SNOWSQL_PRV_KEY_PASS = Variable.get("oasis_manufacturing-execution-df/MWAA_TRANSFORM_SNOWSQL_PRV_KEY_PASS")
ACCOUNT = "SANOFI-EMEA_DF_IA"
SNOWSQL_DATABASE = "IA_MANUFACTURING_EXECUTION_DEV"
SNOWSQL_ROLE = "IA_MANUFACTURING_EXECUTION_DEV_TRANSFORM_PROC"
SNOWSQL_WAREHOUSE = "IA_MANUFACTURING_EXECUTION_DEV_WH_ADHOC"

def db_connection_init():
    try:
        # Load the private key
        logger.info("private key decoding is in progress")
        private_bytes = base64.b64decode(SNOWSQL_PRV_KEY)
        logger.info("private key decoding is completed")

        # Try to load the private key
        try:
            logger.info("DER/PEM prv key serialization is in progress")
            p_key = serialization.load_der_private_key(
                data=private_bytes,
                password=SNOWSQL_PRV_KEY_PASS.encode(),
                backend=default_backend(),
            )
        except ValueError as e:
            logger.error(f"Failed to load key in DER format: {e}")
            try:
                # Try loading the private key as PEM (if applicable)
                p_key = serialization.load_pem_private_key(
                    data=private_bytes,
                    password=SNOWSQL_PRV_KEY_PASS.encode(),
                    backend=default_backend(),
                )
            except ValueError as e:
                logger.error(f"Failed to load key in PEM format: {e}")
                raise

        logger.info("DER/PEM prv key serialization is completed")

        # Try serializing the key
        try:
            logger.info(f"prv key serialization is in progress")
            pkb = p_key.private_bytes(
                encoding=serialization.Encoding.DER,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption(),
            )
            logger.info(f"prv key serialization is completed")
        except ValueError as e:
            logger.error(f"Failed to serialize the key: {e}")
            raise

        # Connecting to Snowflake
        logger.info("Connecting to Snowflake is in progress")
        try:
            connection = snow.connect(
                account=ACCOUNT,
                user=SNOWSQL_TRANSFORM_USER,
                private_key=pkb,
                role=SNOWSQL_ROLE,
                warehouse=SNOWSQL_WAREHOUSE,
                database=SNOWSQL_DATABASE,
            )
            logger.info("Connection to Snowflake is completed")
            return connection
        except Exception as e:
            logger.error(f"Failed to connect to Snowflake: {e}")
            raise
    except Exception as e:
        logger.error(f"An unexpected error occurred: {e}")
        raise

def get_session_info(region, env_name):

    logging.basicConfig(level=logging.INFO)

    try:
        # Initialize MWAA client and request a web login token
        mwaa = boto3.client("mwaa", region_name=region)
        response = mwaa.create_web_login_token(Name=env_name)

        # Extract the web server hostname and login token
        web_server_host_name = response["WebServerHostname"]
        web_token = response["WebToken"]

        # Construct the URL needed for authentication
        login_url = f"https://{web_server_host_name}/aws_mwaa/login"
        login_payload = {"token": web_token}

        # Make a POST request to the MWAA login url using the login payload
        response = requests.post(login_url, data=login_payload, timeout=10)

        # Check if login was succesfull
        if response.status_code == 200:
            # Return the hostname and the session cookie
            return web_server_host_name, response.cookies["session"]
        else:
            # Log an error
            logging.error("Failed to log in: HTTP %d", response.status_code)
            return None, None
    except requests.RequestException as e:
        # Log any exceptions raised during the request to the MWAA login endpoint
        logging.error("Request failed: %s", str(e))
        return None, None
    except Exception as e:
        # Log any other unexpected exceptions
        logging.error("An unexpected error occurred: %s", str(e))
        return None, None


def create_dataset_event(**kwargs):

    dataset_uri = kwargs.get("dataset_uri")
    if not dataset_uri:
        logging.error("No dataset_uri provided")
        return None

    try:
        web_server_host_name, session_cookie = get_session_info(REGION_NAME, ENV_NAME)
        if not session_cookie:
            logging.error("Authentication failed, no session cookie retrieved.")
            return None
    except Exception as e:
        logging.error(f"Error retrieving session info: {str(e)}")
        return None

    # Prepare headers and payload for the request
    cookies = {"session": session_cookie}

    # Utiliser les valeurs
    json_body = {"dataset_uri": dataset_uri, "extra": {}}
    url = f"https://{web_server_host_name}/api/v1/datasets/events"
    logging.info(f"Target URL: {url}")

    try:
        response = requests.post(url, cookies=cookies, json=json_body)
        if response.status_code == 200:
            logging.info(
                f"Dataset event created successfully for {dataset_uri}: {response.status_code} - {response.text}"
            )
            return response.json()  # Assuming the response is JSON
        else:
            logging.error(
                f"Failed to create dataset event: HTTP {response.status_code} - {response.text}"
            )
            return None
    except requests.RequestException as e:
        logging.error(f"Request to create dataset event failed: {e}")
        return None


def scan_and_trigger_dags(**kwargs):
    """
    Scans the Snowflake audit_process stream for new records.
    Filters by allowed PROCESS_IDs in Python.
    Triggers dataset events for valid rows and consumes the stream regardless of result content.
    """
    # Liste des PROCESS_ID autorisés
    allowed_process_ids = {12635, 12645, 12627, 12626}

    try:
        logging.info("Initializing database connection...")
        with db_connection_init() as conn:
            logging.info("Database connection established.")
            with conn.cursor() as cursor:
                logging.info("Cursor initialized.")

                # 1. Lire toutes les lignes du stream
                query = """
                    SELECT * 
                    FROM IA_MANUFACTURING_EXECUTION_DEV.PSA_SAP_HUB.str_srv_audit_process;
                """
                logging.info(f"Executing query: {query}")
                cursor.execute(query)
                records = cursor.fetchall()
                column_names = [desc[0] for desc in cursor.description]
                logging.info(f"Columns in result: {column_names}")
                logging.info(f"Total rows retrieved from stream: {len(records)}")

                triggered_jobs = []

                # 2. Parcourir les lignes et filtrer selon PROCESS_ID
                for i, record in enumerate(records):
                    try:
                        logging.info(f"Processing row {i+1}: {record}")

                        process_id = record[0]
                        process_nm = str(record[1]) if record[1] else ""
                        application_name = str(record[2]) if record[2] else ""

                        # Skip if process_id not in allowed list
                        if process_id not in allowed_process_ids:
                            logging.info(f"Skipping row {i+1} — PROCESS_ID {process_id} not in allowed list.")
                            continue

                        # Vérifie que tous les champs sont valides
                        if not (process_id and process_nm and application_name):
                            logging.warning(f"Missing required fields in row {i+1}, skipping.")
                            continue

                        dataset_uri = f"{process_id}_{process_nm}_{application_name}"
                        logging.info(f"Generated dataset_uri: {dataset_uri}")

                        response = create_dataset_event(dataset_uri=dataset_uri)
                        triggered_jobs.append(dataset_uri)
                        logging.info(f"Dataset event triggered for: {dataset_uri}")

                    except Exception as e:
                        logging.error(f"Error processing row {i+1}: {str(e)}")
                        continue

                # 3. Consommer le stream même si aucun dataset n'a été déclenché
                stream_consumption_query = """
                    INSERT INTO IA_MANUFACTURING_EXECUTION_DEV.PSA_SAP_HUB.audit_process_stream_sink
                    SELECT * 
                    FROM IA_MANUFACTURING_EXECUTION_DEV.PSA_SAP_HUB.str_srv_audit_process;
                """
                logging.info("Consuming stream offset...")
                cursor.execute(stream_consumption_query)
                logging.info("Stream successfully consumed.")

                return triggered_jobs

    except Exception as e:
        logging.error(f"Fatal error in scan_and_trigger_dags: {str(e)}")
        raise



def get_session_info_wrapper(**kwargs):

    return get_session_info(region=REGION_NAME, env_name=ENV_NAME)


default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "start_date": days_ago(1),
    "retries": 1,
    "email_on_failure": True,
    "email_on_retry": False,
}

dag_manager = DAG(
    "snowflake_mwaa_manager_dag",
    default_args=default_args,
    description="DAG Manager that pase audit snwoflake table to create dataset events",
    schedule_interval=timedelta(minutes=5),
    catchup=False,
    access_control={
        "MWAA_MANUFACTURING_EXECUTION_DEVELOPERS": ["can_read","can_edit"],
        "MWAA_MANUFACTURING_EXECUTION_SUPPORT": ["can_read", "can_edit"],
        "MWAA_MANUFACTURING_EXECUTION_USERS": ["can_read"]
        }
)

get_session_info_task = PythonOperator(
    task_id="get_session_info",
    python_callable=get_session_info_wrapper,
    dag=dag_manager,
)

scan_task = PythonOperator(
    task_id="scan_and_trigger_dags",
    python_callable=scan_and_trigger_dags,
    provide_context=True,
    dag=dag_manager,
)

get_session_info_task >> scan_task
