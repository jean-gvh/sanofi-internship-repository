from airflow import DAG
from airflow.datasets import Dataset
from airflow.timetables.trigger import CronTriggerTimetable
from airflow.timetables.datasets import DatasetOrTimeSchedule
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta

# Define your datasets
mwaa_s3_executor_dataset_A = Dataset("12635_TF_HUB_SAP_SAP_SHIFT_daily_SAP_SHIFT")


# Define a function that will be executed by the DAG
def process_data(**kwargs):
    """Process the data from the dataset."""
    # Get the triggering dataset if this run was triggered by a dataset
    triggering_dataset = kwargs.get("triggering_datasets", [])

    if triggering_dataset:
        print(f"This DAG was triggered by dataset: {triggering_dataset[0]}")
    else:
        print("This DAG as triggered by the time schedule fallback (daily cron)")

    # Your processing logic here
    print("Processing data....")


# Define the DAG
with DAG(
    dag_id="snowflake-mwaa-dag-executor",
    # This is the key part: Use DatasetOrTimeSchedule to combine dataset triggers with time-based fallback
    schedule=DatasetOrTimeSchedule(
        # This will trigger the DAG daily at 1 AM UTC if no dataset event occurs
        timetable=CronTriggerTimetable("0 1 * * *", timezone="UTC"),
        # This will trigger the DAG whenever the dataset is updated
        datasets=[mwaa_s3_executor_dataset_A],
    ),
    start_date=datetime(2025, 2, 3),
    catchup=False,
    tags=["dataset", "timetable"],
    default_args={
        "owner": "airflow",
        "retries": 1,
        "retry_delay": timedelta(minutes=5),
    },
    access_control={
        "MWAA_MANUFACTURING_EXECUTION_DEVELOPERS": ["can_read","can_edit"],
        "MWAA_MANUFACTURING_EXECUTION_SUPPORT": ["can_read", "can_edit"],
        "MWAA_MANUFACTURING_EXECUTION_USERS": ["can_read"]
        }
) as dag:

    # Task to process the data
    process_task = PythonOperator(
        task_id="process_data",
        python_callable=process_data,
        provide_context=True,
    )
