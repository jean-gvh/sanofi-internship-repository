from datetime import timedelta
import logging
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.models.connection import Connection
from airflow.models import Variable
from airflow.utils.dates import days_ago
import re
import boto3
import requests
from airflow.models import Variable

ENV_NAME = "dev-mwaa-core"
REGION_NAME = "eu-west-1"
ROLE_ARN = "arn:aws:iam::109902045982:role/App_iics-role-for-s3-mex"

BUCKET_NAME = "digital-mwaa-global-dev"
PREFIX = "ACK/unprocessed"
PROCESSED_PREFIX = "ACK/processed"

# Updated common pattern to match files with YYYY-MM-DD date and HH-MM-SS time format
FILE_PATTERN = r"ack_\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}_(.*)\.csv"

# Define the IICS job/Airflow Datasets mapping table
# Maps job_name to corresponding dataset URIs
JOB_DATASET_MAPPING = {
    "M_IA_MANU_EXEC_MWAA_S3_WRITE_A": "s3://ia_manu_exec/datasets/mwaa_s3_executor_A",
    "M_IA_MANU_EXEC_MWAA_S3_WRITE_B": "s3://ia_manu_exec/datasets/mwaa_s3_executor_B",
    "IICS_JOB_3": "IICS_JOB_3_dataset",
}


def get_dataset_for_job(job_name: str):
    """
    Returns the dataset for a given job name from the mapping table.
    Returns None if no mapping exists.
    """
    return JOB_DATASET_MAPPING.get(job_name)


def create_dataset_event(dataset_uri: str):
    try:
        web_server_host_name, session_cookie = get_session_info(REGION_NAME, ENV_NAME)
        if not session_cookie:
            logging.error("Authentication failed, no session cookie retrieved.")
            return
    except Exception as e:
        logging.error(f"Error retrieving session info: {str(e)}")
        return

    # Prepare headers and payload for the request
    cookies = {"session": session_cookie}

    # Utiliser les valeurs
    json_body = {"dataset_uri": dataset_uri, "extra": {}}
    url = f"https://{web_server_host_name}/api/v1/datasets/events"
    print(f"target url", url)

    try:
        response = requests.post(url, cookies=cookies, json=json_body)
        if response.status_code == 200:
            print(
                f"Dataset event created successfully for {dataset_uri} dataset,{response.status_code} - {response.text}"
            )
        else:
            print(
                f"Failed to create dataset event: HTTP {response.status_code} - {response.text}"
            )
    except requests.RequestException as e:
        print(f"Request to create dataset event failed: {e}")


def get_session_info(region, env_name):
    logging.basicConfig(level=logging.INFO)

    try:
        # Initialize MWAA client and request a web login token
        mwaa = boto3.client("mwaa", region_name=region)
        response = mwaa.create_web_login_token(Name=env_name)

        # Extract the web server hostname and login token
        web_server_host_name = response["WebServerHostname"]
        web_token = response["WebToken"]

        # Construct the URL needed for authentication
        login_url = f"https://{web_server_host_name}/aws_mwaa/login"
        login_payload = {"token": web_token}

        # Make a POST request to the MWAA login url using the login payload
        response = requests.post(login_url, data=login_payload, timeout=10)

        # Check if login was succesfull
        if response.status_code == 200:

            # Return the hostname and the session cookie
            return (web_server_host_name, response.cookies["session"])
        else:
            # Log an error
            logging.error("Failed to log in: HTTP %d", response.status_code)
            return None
    except requests.RequestException as e:
        # Log any exceptions raised during the request to the MWAA login endpoint
        logging.error("Request failed: %s", str(e))
        return None
    except Exception as e:
        # Log any other unexpected exceptions
        logging.error("An unexpected error occurred: %s", str(e))
        return None


def scan_and_trigger_dags():

    conn = Connection(
        conn_id="mwaa_s3_conn",
        conn_type="aws",
        extra={
            "region_name": REGION_NAME,
            "role_arn": ROLE_ARN,
        },
    )

    s3_hook = S3Hook(aws_conn_id=conn.conn_id)

    s3_objects = s3_hook.list_keys(bucket_name=BUCKET_NAME, prefix=PREFIX)

    if not s3_objects:
        print(f"No files found in {BUCKET_NAME}/{PREFIX}")
        return []

    triggered_jobs = []

    for s3_key in s3_objects:
        if s3_key.endswith("/"):
            continue

        filename = s3_key.split("/")[-1]

        if filename.startswith("ack"):
            match = re.match(FILE_PATTERN, filename)
            if match:
                job_name = match.group(1)
                dataset = get_dataset_for_job(job_name)

                if dataset:
                    
                    create_dataset_event(dataset_uri=dataset)

                processed_key = f"{PROCESSED_PREFIX}/{filename}"
                print(f"s3_key: {s3_key}")
                print(f"s3_processed_key: {processed_key}")

                s3_hook.get_conn().copy_object(
                    Bucket=BUCKET_NAME,
                    CopySource={"Bucket": BUCKET_NAME, "Key": s3_key},
                    Key=processed_key,
                )

                s3_hook.delete_objects(bucket=BUCKET_NAME, keys=[s3_key])

                print("Ack file transferred successfully")
                triggered_jobs.append((job_name, filename))
            else:
                print(f"No matching DAG pattern for file {filename}")
        else:
            print(f"Skipping file {filename} as it doesn't start with 'ack'")

    return triggered_jobs


default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "start_date": days_ago(1),
    "retries": 1,
    "email_on_failure": True,
    "email_on_retry": False,
}

dag_manager = DAG(
    "s3_dag_manager_api",
    default_args=default_args,
    description="DAG Manager that monitors S3 and triggers other DAGs",
    schedule_interval=timedelta(minutes=5),
    catchup=False,
)



scan_task = PythonOperator(
    task_id="scan_and_trigger_dags",
    python_callable=scan_and_trigger_dags,
    provide_context=True,
    dag=dag_manager,
)

scan_task
