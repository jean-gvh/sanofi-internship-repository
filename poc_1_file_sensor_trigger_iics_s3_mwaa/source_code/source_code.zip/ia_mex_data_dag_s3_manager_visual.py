from airflow import DAG
from airflow.operators.python import PythonOperator, BranchPythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.datasets import Dataset
from datetime import datetime, timedelta
import re
from typing import List, Tuple, Dict, Optional

BUCKET_NAME = "digital-mwaa-global-dev"
PREFIX = "ACK/unprocessed"
PROCESSED_PREFIX = "ACK/processed"

# Updated common pattern to match files with YYYY-MM-DD date and HH-MM-SS time format
FILE_PATTERN = r"ack_\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}_(.*)\.csv"

# Define the datasets in advance
MWAA_S3_EXECUTOR_DATASET = Dataset("s3://ia_manu_exec/datasets/mwaa_s3_executor")
ANOTHER_DATASET = Dataset("s3://another/dataset/uri")  # Example dataset
YET_ANOTHER_DATASET = Dataset("s3://yet/another/dataset/uri")  # Example dataset

# Define the IICS job/Airflow Datasets mapping table
# Maps job_name to corresponding dataset URIs
JOB_DATASET_MAPPING = {
    "M_IA_MANU_EXEC_MWAA_S3_WRITE": MWAA_S3_EXECUTOR_DATASET,
    "ANOTHER_JOB_NAME": ANOTHER_DATASET,  # Example mapping
    "YET_ANOTHER_JOB_NAME": YET_ANOTHER_DATASET,  # Example mapping
}


def get_dataset_for_job(job_name: str) -> Optional[Dataset]:
    """
    Returns the dataset for a given job name from the mapping table.
    Returns None if no mapping exists.
    """
    return JOB_DATASET_MAPPING.get(job_name)


def scan_and_trigger_dags(**context) -> List[Tuple[str, str]]:
    """
    Scans the S3 bucket, identifies matching files, and returns the job names
    that triggered the DAG.
    """
    s3_hook = S3Hook(aws_conn_id="mwaa_s3_conn")

    # List all objects in the prefix
    s3_objects = s3_hook.list_keys(bucket_name=BUCKET_NAME, prefix=PREFIX)

    if not s3_objects:
        print(f"No files found in {BUCKET_NAME}/{PREFIX}")
        return []

    # Track all the datasets we produce
    triggered_jobs = []

    for s3_key in s3_objects:
        # Skip folders
        if s3_key.endswith("/"):
            continue

        # Extract the filename from the full path
        filename = s3_key.split("/")[-1]

        # Check if the filename starts with 'ack' and matches the pattern
        if filename.startswith("ack"):
            match = re.match(FILE_PATTERN, filename)
            if match:
                # Extract job name from the matched group
                job_name = match.group(1)

                # Look up the dataset from the mapping table
                dataset = get_dataset_for_job(job_name)

                if dataset:
                    # Add the job name to the list of triggered jobs
                    triggered_jobs.append(job_name)
                    print(f"Found dataset for job '{job_name}' with URI {dataset.uri}")
                else:
                    print(f"Warning: No dataset mapping found for job '{job_name}'")

                # Move the file to the processed folder
                processed_key = f"{PROCESSED_PREFIX}/{filename}"
                print(f"s3_key: {s3_key}")
                print(f"s3_processed_key: {processed_key}")

                # Copy the file without ACLs
                s3_hook.get_conn().copy_object(
                    Bucket=BUCKET_NAME,
                    CopySource={"Bucket": BUCKET_NAME, "Key": s3_key},
                    Key=processed_key,
                )

                # Delete the original file
                s3_hook.delete_objects(bucket=BUCKET_NAME, keys=[s3_key])

                print(f"Ack file {filename} transferred successfully")
            else:
                print(f"No matching pattern for file {filename}")
        else:
            print(f"Skipping file {filename} as it doesn't start with 'ack'")

    # Store the triggered jobs in XCom for other tasks to use
    context["ti"].xcom_push(key="triggered_jobs", value=triggered_jobs)

    return triggered_jobs


def decide_branch(**context) -> str:
    """
    Decides which branch to execute based on the triggered jobs.
    """
    # Get the triggered jobs from XCom
    ti = context["ti"]
    triggered_jobs = ti.xcom_pull(
        task_ids="scan_and_trigger_dags", key="triggered_jobs"
    )

    if not triggered_jobs:
        print("No jobs were triggered")
        return "no_update"

    # Decide which branch to execute based on the triggered jobs
    if "M_IA_MANU_EXEC_MWAA_S3_WRITE" in triggered_jobs:
        return "update_mwaa_s3_executor"
    elif "ANOTHER_JOB_NAME" in triggered_jobs:
        return "update_another_dataset"
    elif "YET_ANOTHER_JOB_NAME" in triggered_jobs:
        return "update_yet_another_dataset"
    else:
        return "no_update"


def update_mwaa_s3_executor(**context):
    """
    Task that updates the MWAA S3 Executor dataset.
    """
    print("Updating MWAA S3 Executor dataset")
    return


def update_another_dataset(**context):
    """
    Task that updates the Another dataset.
    """
    print("Updating Another dataset")
    return


def update_yet_another_dataset(**context):
    """
    Task that updates the Yet Another dataset.
    """
    print("Updating Yet Another dataset")
    return


default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "start_date": datetime(2025, 2, 3),
    "retries": 1,
    "email_on_failure": True,
    "email_on_retry": False,
}

dag_manager = DAG(
    "s3_dag_manager_optimized",
    default_args=default_args,
    description="DAG Manager that monitors S3 and triggers other DAGs",
    schedule_interval=timedelta(minutes=5),  # Runs every 5 minutes
    catchup=False,
)

# Define tasks
scan_task = PythonOperator(
    task_id="scan_and_trigger_dags",
    python_callable=scan_and_trigger_dags,
    provide_context=True,
    dag=dag_manager,
)

branch_task = BranchPythonOperator(
    task_id="decide_branch",
    python_callable=decide_branch,
    provide_context=True,
    dag=dag_manager,
)

update_mwaa_s3_executor_task = PythonOperator(
    task_id="update_mwaa_s3_executor",
    python_callable=update_mwaa_s3_executor,
    provide_context=True,
    outlets=[MWAA_S3_EXECUTOR_DATASET],  # Define the dataset for this task
    dag=dag_manager,
)

update_another_dataset_task = PythonOperator(
    task_id="update_another_dataset",
    python_callable=update_another_dataset,
    provide_context=True,
    outlets=[ANOTHER_DATASET],  # Define the dataset for this task
    dag=dag_manager,
)

update_yet_another_dataset_task = PythonOperator(
    task_id="update_yet_another_dataset",
    python_callable=update_yet_another_dataset,
    provide_context=True,
    outlets=[YET_ANOTHER_DATASET],  # Define the dataset for this task
    dag=dag_manager,
)

no_update_task = DummyOperator(
    task_id="no_update",
    dag=dag_manager,
)

end_task = DummyOperator(
    task_id="end",
    trigger_rule="none_failed",  # Ensure this task runs even if some branches are skipped
    dag=dag_manager,
)

# Set the task dependencies
scan_task >> branch_task
branch_task >> [
    update_mwaa_s3_executor_task,
    update_another_dataset_task,
    update_yet_another_dataset_task,
    no_update_task,
]
[
    update_mwaa_s3_executor_task,
    update_another_dataset_task,
    update_yet_another_dataset_task,
    no_update_task,
] >> end_task
